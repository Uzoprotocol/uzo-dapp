export { default } from './UzoIcon'
