export { default } from './Label'
