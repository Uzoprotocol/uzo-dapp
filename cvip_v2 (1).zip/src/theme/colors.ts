export const white = '#e2660b'
export const black = '#035b96'

export const green = {
  500: '#333',
}

export const red = {
  100: '#e2660b',
  200: '#e2660b',
  500: '#fff',
}

export const grey = {
  100: '#e2660b',
  200: '#2a2a2af7',
  300: '#f68f19',
  400: '#eee',
  500: '#fff',
  600: '#fff',
  800: '#fff',
}
