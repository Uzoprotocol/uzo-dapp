//export const uzo = '0x0e2298e3b3390e3b945a5456fbf59ecc3f55da16'
export const uzov2 = '0xFCBaf6f9c56074297930034b38425f56BE20b5A2'
export const uzoAddress = '0x04FAb3f8c4F45930De257F249b54BC3237cafE26'
export const masterChefAddress = '0xE1c3c53688026BA52D255Aeb3eD5623e88aF4F56'
